# 📐 Архітектурний Контракт DNK-Ecom-Zerno-v.0.1.0 («Зерно»)

Повна специфікація архітектури, деконструкція світових лідерів та дорожня карта:
* **Канонічна специфікація**: `docs/architecture/specs/DNK_ECOM_THEME_MASTER_SPEC_V1.md`
* **DEC Запис**: `DEC-136` у `docs/architecture/DECISION_REGISTRY_ADHD.md`
* **7 Воріт Якості (Checkpoint Engine)**:
  1. `Gate 0`: Foundation — Design Tokens (`assets/dnk-tokens.css`) & CSSOM Reset.
  2. `Gate 1`: Core Runtime — `assets/dnk-core.js` (W3C Elements, Cart Mutation Queue, Iframe Fetch).
  3. `Gate 2`: Global Chrome — Accessible `layout/theme.liquid`, Header, Footer, Predictive Search.
  4. `Gate 3`: Cart Engine — High-CRO Drawer with Multi-Tier Shipping Bar & Upsells.
  5. `Gate 4`: PDP 2.0 Engine — Theme Blocks 2.0, Category Metafield Visual Swatches, Sticky ATC.
  6. `Gate 5`: Catalog Discovery — Section Rendering API Facets, Product Card with Hover Media.
  7. `Gate 6`: Theme Store Ready — Full Locales, Customer Account Templates, 0-Error Theme Check.
