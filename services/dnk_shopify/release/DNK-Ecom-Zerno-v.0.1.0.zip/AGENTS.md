---
title: "DNK Ecom Flagship Theme Governance"
status: active
type: governance
domain: shopify_theme
author: "DNK-e.com Maksym & Antigravity"
version: "1.0.0"
---

> [!metadata]- ⚙️ Системні метадані та інваріанти (MRH Header)
> ```yaml
> # --- DNK-MRH-HEADER ---
> mrh_id: "AGENTS.md"
> purpose: "Strict Governance Rules for Zernyatko Flagship Theme Development."
> canonical_source: true
> alters_files: []
> triggers_tasks: []
> status: "Active"
> version: "1.0.0"
> updated_at: "2026-11-18"
> author: "DNK-e.com Maksym & Antigravity"
> # --- END DNK-MRH-HEADER ---
> ```

# 🛡️ Правила Розробки Теми DNK-Ecom-Zerno-v.0.1.0 («Зерно»)

1. **Clean Slate & Zero Generative Bloat**:
   * Заборонено масове сліпе копіювання монолітних сніпетів без попереднього проходження чекпоінтів.
   * Кожен файл створюється осмислено знизу вгору: Tokens ➔ Runtime ➔ Chrome ➔ Cart ➔ PDP ➔ Discovery ➔ Certification.
2. **3-Tier Git Flow**:
   * `mvp` ➔ активна розробка, закриття чекпоінтів 0–6.
   * `pre-release` ➔ повний цикл верифікації (Theme Check, Lighthouse 90+, WCAG AA).
   * `main` ➔ релізна версія для продажу та бойових клієнтів.
3. **W3C Custom Elements & Pure JavaScript**:
   * Жодних важких сторонніх бібліотек (jQuery, React, Alpine, Lodash).
   * Усі інтерактивні елементи наслідують `DnkElement` із `assets/dnk-core.js`.
4. **Theme Blocks 2.0 Invariant**:
   * 100% відповідність стандарту Horizon: блоки в `blocks/`, імена схем ≤ 25 символів, підтримка вкладеності до 8 рівнів через `_group.liquid`.
