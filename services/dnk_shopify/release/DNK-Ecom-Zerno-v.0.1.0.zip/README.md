# 🌾 Тема «Зерно» — DNK-Ecom-Zerno-v.0.1.0

> **Shopify Theme Store Commercial Flagship ($350–$420 MSRP) & High-CRO Client Deployment Standard**

---

## 🌿 3-Tier Branching Strategy

| Гілка | Назва | Призначення |
|---|---|---|
| **`main`** | **Commercial Sale Version** | Фінальна продажна версія теми, що проходить модерацію Shopify Theme Store та розгортається на бойові магазини клієнтів. |
| **`pre-release`** | **Testing & Staging Gate** | Буферна гілка перед пушем у `main`. Тут проводяться комплексні аудити: Lighthouse 90+, `shopify theme check`, стрес-тести та a11y WCAG AA. |
| **`mvp`** | **Active Development** | Гілка активної розробки теми "з нуля" за детермінованою системою 7 воріт якості (Checkpoint 0 ➔ Checkpoint 6). |

---

## 🧬 Бібліотека Донорів (Donor Catalog Reference)

Розробка ведеться з чистого аркуша з запозиченням найкращих рішень із синхронізованих донорів у сусідніх робочих копіях (`worktrees`):

* **`tinker` (Horizon)** — Офіційний референс Shopify: Theme Blocks 2.0 (вкладеність до 8 рівнів), `@theme` Sidekick Discovery, `liquid_doc` пропси.
* **`sugar`** — DTC лідер: `__sugarGiftLinesSplit` (ізоляція фетчу через чистий iframe, захист рекламних пікселів Meta/Google).
* **`story`** — Модульна архітектура W3C Web Components, scoped stylesheets.
* **`shrine-pro`** — No-App CRO механіки: Sticky ATC, вбудований багаторівневий прогрес-бар кошика, Volume Pricing.
* **`casaio`, `elixir`, `ella`, `ks-origin`** — Спеціалізовані дизайн-патерни та промо-секції.

---

## 🛡️ Контроль Якості

Розробка в гілці `mvp` підпорядкована 7-Gate Checkpoint Engine у ядрі DNK OS:
```bash
just shopify-checkpoints
```
