/**
 * --- DNK-MRH-HEADER ---
 * mrh_id: "assets/dnk-core.js"
 * purpose: "Unified W3C Custom Elements Microkernel, Event Bus & Cart Mutation Queue."
 * canonical_source: true
 * alters_files: []
 * triggers_tasks: []
 * status: "Active"
 * version: "1.0.0"
 * updated_at: "2026-11-17"
 * author: "DNK-e.com Maksym & Antigravity"
 * --- END DNK-MRH-HEADER ---
 */

(function () {
  "use strict";

  // Prevent multiple initializations
  if (window.DNK && window.DNK.__initialized) {
    return;
  }

  /* ========================================================================
     1. GLOBAL EVENT BUS & DISPATCHER
     ======================================================================== */
  class DnkEventBus {
    constructor() {
      this.target = new EventTarget();
    }

    /**
     * Subscribe to a custom DNK event
     * @param {string} eventName
     * @param {Function} handler
     */
    on(eventName, handler) {
      this.target.addEventListener(eventName, handler);
      return () => this.off(eventName, handler);
    }

    /**
     * Unsubscribe from a custom DNK event
     * @param {string} eventName
     * @param {Function} handler
     */
    off(eventName, handler) {
      this.target.removeEventListener(eventName, handler);
    }

    /**
     * Dispatch an event through the global bus and document root
     * @param {string} eventName
     * @param {any} detail
     */
    emit(eventName, detail = {}) {
      const customEvent = new CustomEvent(eventName, {
        detail,
        bubbles: true,
        composed: true,
        cancelable: true,
      });
      this.target.dispatchEvent(customEvent);
      document.dispatchEvent(customEvent);
      return customEvent;
    }
  }

  const events = new DnkEventBus();

  /* ========================================================================
     2. CLEANROOM ATTRIBUTION FETCH (IFRAME ISOLATION PATTERN)
     ======================================================================== */
  /**
   * Bypasses rogue monkey-patched window.fetch from third-party marketing apps
   * by maintaining a cleanroom same-origin hidden iframe fetch pipeline.
   */
  let cleanroomIframe = null;

  function getCleanroomFetch() {
    try {
      if (!cleanroomIframe && typeof document !== "undefined") {
        cleanroomIframe = document.createElement("iframe");
        cleanroomIframe.style.display = "none";
        cleanroomIframe.setAttribute("aria-hidden", "true");
        cleanroomIframe.src = "about:blank";
        document.head.appendChild(cleanroomIframe);
      }
      if (cleanroomIframe && cleanroomIframe.contentWindow && cleanroomIframe.contentWindow.fetch) {
        return cleanroomIframe.contentWindow.fetch.bind(cleanroomIframe.contentWindow);
      }
    } catch (e) {
      // Fallback gracefully to window.fetch if sandboxing restricts iframe
    }
    return window.fetch.bind(window);
  }

  async function cleanroomFetch(url, options = {}) {
    const rawFetch = getCleanroomFetch();
    const headers = Object.assign(
      {
        "X-Requested-With": "XMLHttpRequest",
        Accept: "application/json",
      },
      options.headers || {}
    );
    return rawFetch(url, Object.assign({}, options, { headers }));
  }

  /* ========================================================================
     3. SEQUENTIAL CART MUTATION QUEUE (RACE-CONDITION PROOF)
     ======================================================================== */
  class CartMutationQueue {
    constructor() {
      this.queue = [];
      this.isProcessing = false;
      this.latestCart = null;
    }

    /**
     * Enqueue a cart mutation
     * @param {Function} task - Async mutation function returning cart JSON
     * @returns {Promise<any>}
     */
    enqueue(task) {
      return new Promise((resolve, reject) => {
        this.queue.push({ task, resolve, reject });
        this.processNext();
      });
    }

    async processNext() {
      if (this.isProcessing || this.queue.length === 0) {
        return;
      }

      this.isProcessing = true;
      const { task, resolve, reject } = this.queue.shift();

      try {
        events.emit("dnk:cart:loading", { isBusy: true });
        const result = await task();
        this.latestCart = result;
        events.emit("dnk:cart:updated", { cart: result });
        resolve(result);
      } catch (err) {
        console.error("[DNK-Core] Cart mutation failed:", err);
        events.emit("dnk:cart:error", { error: err });
        reject(err);
      } finally {
        this.isProcessing = false;
        if (this.queue.length === 0) {
          events.emit("dnk:cart:loading", { isBusy: false });
        }
        this.processNext();
      }
    }

    /**
     * Add item to cart with Cleanroom attribution splitting
     * @param {Object} payload - { items: [...], sections: [] }
     */
    async addItem(payload) {
      return this.enqueue(async () => {
        const res = await cleanroomFetch("/cart/add.js", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.description || errData.message || "Failed to add to cart");
        }
        const cartState = await cleanroomFetch("/cart.js").then((r) => r.json());
        return cartState;
      });
    }

    /**
     * Change quantity or line properties
     * @param {string|number} line - Line number or key
     * @param {number} quantity
     * @param {Object} [properties]
     */
    async changeItem(line, quantity, properties = null) {
      return this.enqueue(async () => {
        const body = { id: line, quantity: Number(quantity) };
        if (properties) body.properties = properties;

        const res = await cleanroomFetch("/cart/change.js", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.description || errData.message || "Failed to update cart line");
        }
        return res.json();
      });
    }

    /**
     * Retrieve fresh cart JSON state
     */
    async getCart() {
      const res = await cleanroomFetch("/cart.js");
      const cart = await res.json();
      this.latestCart = cart;
      return cart;
    }
  }

  const cartQueue = new CartMutationQueue();

  /* ========================================================================
     4. W3C CUSTOM ELEMENT BASE CLASS (DnkElement)
     ======================================================================== */
  class DnkElement extends HTMLElement {
    constructor() {
      super();
      this._unsubscribers = [];
    }

    connectedCallback() {
      this.setup();
    }

    disconnectedCallback() {
      this.teardown();
      this._unsubscribers.forEach((unsub) => {
        try {
          unsub();
        } catch (e) {
          /* no-op */
        }
      });
      this._unsubscribers = [];
    }

    /**
     * Lifecycle hook for element initialization
     */
    setup() {}

    /**
     * Lifecycle hook for element teardown
     */
    teardown() {}

    /**
     * Subscribe to EventBus and store unregister hook
     */
    listen(eventName, handler) {
      const unsub = events.on(eventName, handler.bind(this));
      this._unsubscribers.push(unsub);
      return unsub;
    }

    /**
     * Dispatch namespaced event
     */
    dispatch(name, detail = {}) {
      return events.emit(`dnk:${name}`, detail);
    }
  }

  /* ========================================================================
     5. GLOBAL EXPOSURE & REGISTRATION
     ======================================================================== */
  window.DNK = {
    __initialized: true,
    version: "1.0.0-mvp",
    events,
    cartQueue,
    cleanroomFetch,
    DnkElement,
    /**
     * Register a new custom element safely
     * @param {string} tag
     * @param {CustomElementConstructor} constructorClass
     */
    define(tag, constructorClass) {
      if (!customElements.get(tag)) {
        customElements.define(tag, constructorClass);
      }
    },
  };

  // Signal ready state
  events.emit("dnk:core:ready", { version: window.DNK.version });
})();
