/**
 * --- DNK OS Zerno Flagship: Section Rendering Facets ---
 * High-performance, zero-refresh catalog filtering via Shopify Section Rendering API.
 */

if (!customElements.get('dnk-facets')) {
  class DnkFacets extends HTMLElement {
    constructor() {
      super();
      this._onChange = this._onChange.bind(this);
      this._onPopState = this._onPopState.bind(this);
    }

    connectedCallback() {
      this.addEventListener('change', this._onChange);
      window.addEventListener('popstate', this._onPopState);
    }

    disconnectedCallback() {
      this.removeEventListener('change', this._onChange);
      window.removeEventListener('popstate', this._onPopState);
    }

    _onChange(e) {
      const form = this.querySelector('form') || this.closest('form');
      if (!form) return;

      const formData = new FormData(form);
      const searchParams = new URLSearchParams(formData);

      // Clean empty params
      const entries = Array.from(searchParams.entries());
      for (const [key, value] of entries) {
        if (!value) searchParams.delete(key);
      }

      const queryString = searchParams.toString();
      this.fetchSection(queryString);
    }

    _onPopState() {
      const queryString = window.location.search.slice(1);
      this.fetchSection(queryString, false);
    }

    async fetchSection(queryString, updateUrl = true) {
      const sectionId = this.dataset.sectionId || 'main-collection';
      const url = `${window.location.pathname}?${queryString}&sections=${sectionId}`;

      const grid = document.getElementById('DnkProductGrid');
      if (grid) grid.setAttribute('data-loading', 'true');

      try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`HTTP error ${response.status}`);
        const data = await response.json();

        if (data[sectionId]) {
          const parser = new DOMParser();
          const doc = parser.parseFromString(data[sectionId], 'text/html');

          const newGrid = doc.getElementById('DnkProductGrid');
          if (grid && newGrid) {
            grid.innerHTML = newGrid.innerHTML;
          }

          const newFacets = doc.querySelector('dnk-facets');
          if (newFacets) {
            this.innerHTML = newFacets.innerHTML;
          }

          if (updateUrl) {
            const newUrl = `${window.location.pathname}${queryString ? '?' + queryString : ''}`;
            window.history.pushState({ path: newUrl }, '', newUrl);
          }

          if (window.DNK && window.DNK.events) {
            window.DNK.events.emit('dnk:facets:updated', { query: queryString });
          }
        }
      } catch (err) {
        console.error('Failed to filter collection', err);
      } finally {
        if (grid) grid.removeAttribute('data-loading');
      }
    }
  }

  customElements.define('dnk-facets', DnkFacets);
}
