/**
 * --- DNK OS Zerno Flagship: PDP Custom Elements Runtime ---
 * Includes <dnk-variant-picker>, <dnk-media-gallery>, and <dnk-sticky-atc>.
 */

/* 1. Variant Picker Custom Element */
if (!customElements.get('dnk-variant-picker')) {
  class DnkVariantPicker extends HTMLElement {
    constructor() {
      super();
      this._onChange = this._onChange.bind(this);
    }

    connectedCallback() {
      this.addEventListener('change', this._onChange);
      const dataScript = this.querySelector('script[type="application/json"]');
      if (dataScript) {
        try {
          this.variants = JSON.parse(dataScript.textContent);
        } catch (e) {
          console.error('Failed to parse variant data', e);
        }
      }
    }

    disconnectedCallback() {
      this.removeEventListener('change', this._onChange);
    }

    _onChange(e) {
      const selectedOptions = this.getSelectedOptions();
      const currentVariant = this.findMatchingVariant(selectedOptions);

      if (currentVariant) {
        this.updateForm(currentVariant);
        this.updatePrice(currentVariant);
        this.updateUrl(currentVariant);

        if (window.DNK && window.DNK.events) {
          window.DNK.events.emit('dnk:variant:changed', { variant: currentVariant });
        }
      }
    }

    getSelectedOptions() {
      const options = [];
      const fieldsets = this.querySelectorAll('fieldset');
      fieldsets.forEach(fieldset => {
        const checked = fieldset.querySelector('input:checked');
        if (checked) options.push(checked.value);
      });
      const selects = this.querySelectorAll('select');
      selects.forEach(select => {
        options.push(select.value);
      });
      return options;
    }

    findMatchingVariant(selectedOptions) {
      if (!this.variants) return null;
      return this.variants.find(variant => {
        return selectedOptions.every((val, index) => variant.options[index] === val);
      });
    }

    updateForm(variant) {
      const form = document.getElementById(this.dataset.formId || 'product-form');
      if (!form) return;
      const input = form.querySelector('input[name="id"]');
      if (input) input.value = variant.id;

      const submitBtn = form.querySelector('[type="submit"]');
      if (submitBtn) {
        if (variant.available) {
          submitBtn.removeAttribute('disabled');
          submitBtn.textContent = submitBtn.dataset.atcText || 'Add to Cart';
        } else {
          submitBtn.setAttribute('disabled', 'disabled');
          submitBtn.textContent = submitBtn.dataset.soldOutText || 'Sold Out';
        }
      }
    }

    updatePrice(variant) {
      const priceContainers = document.querySelectorAll('.dnk-pdp-price');
      priceContainers.forEach(container => {
        const cur = container.querySelector('.dnk-price__current');
        if (cur && variant.price_formatted) {
          cur.textContent = variant.price_formatted;
        }
      });
    }

    updateUrl(variant) {
      if (!variant) return;
      const url = new URL(window.location.href);
      url.searchParams.set('variant', variant.id);
      window.history.replaceState({ path: url.toString() }, '', url.toString());
    }
  }

  customElements.define('dnk-variant-picker', DnkVariantPicker);
}

/* 2. Media Gallery Custom Element */
if (!customElements.get('dnk-media-gallery')) {
  class DnkMediaGallery extends HTMLElement {
    constructor() {
      super();
      this._boundVariantChange = this._onVariantChange.bind(this);
    }

    connectedCallback() {
      const thumbs = this.querySelectorAll('[data-target-slide]');
      thumbs.forEach(thumb => {
        thumb.addEventListener('click', (e) => {
          const index = thumb.dataset.targetSlide;
          this.setActiveSlide(index);
        });
      });

      if (window.DNK && window.DNK.events) {
        window.DNK.events.on('dnk:variant:changed', this._boundVariantChange);
      }
    }

    disconnectedCallback() {
      if (window.DNK && window.DNK.events) {
        window.DNK.events.off('dnk:variant:changed', this._boundVariantChange);
      }
    }

    setActiveSlide(index) {
      const slides = this.querySelectorAll('.dnk-media-slide');
      slides.forEach((slide, i) => {
        slide.classList.toggle('dnk-media-slide--active', String(i) === String(index));
      });
      const thumbs = this.querySelectorAll('[data-target-slide]');
      thumbs.forEach((thumb, i) => {
        thumb.classList.toggle('dnk-media-thumb--active', String(i) === String(index));
      });
    }

    _onVariantChange(payload) {
      if (payload && payload.variant && payload.variant.featured_media) {
        const mediaId = String(payload.variant.featured_media.id);
        const targetSlide = this.querySelector(`[data-media-id="${mediaId}"]`);
        if (targetSlide) {
          const index = targetSlide.dataset.slideIndex;
          if (index !== undefined) this.setActiveSlide(index);
        }
      }
    }
  }

  customElements.define('dnk-media-gallery', DnkMediaGallery);
}

/* 3. Sticky ATC Custom Element */
if (!customElements.get('dnk-sticky-atc')) {
  class DnkStickyAtc extends HTMLElement {
    connectedCallback() {
      const targetId = this.dataset.observeId || 'DnkMainBuyButtons';
      const target = document.getElementById(targetId);

      if (target && 'IntersectionObserver' in window) {
        this.observer = new IntersectionObserver((entries) => {
          entries.forEach(entry => {
            // When target is not intersecting (scrolled past), show sticky bar
            if (!entry.isIntersecting && entry.boundingClientRect.top < 0) {
              this.setAttribute('aria-hidden', 'false');
            } else {
              this.setAttribute('aria-hidden', 'true');
            }
          });
        }, { threshold: 0.1 });

        this.observer.observe(target);
      }

      const submitBtn = this.querySelector('[data-action="sticky-atc"]');
      if (submitBtn) {
        submitBtn.addEventListener('click', () => {
          const mainForm = document.getElementById('product-form-main');
          if (mainForm) {
            const formData = new FormData(mainForm);
            const variantId = formData.get('id');
            const qty = parseInt(formData.get('quantity') || '1', 10);
            if (variantId && window.DNK && window.DNK.cartQueue) {
              window.DNK.cartQueue.addItem(variantId, qty);
            }
          }
        });
      }
    }

    disconnectedCallback() {
      if (this.observer) this.observer.disconnect();
    }
  }

  customElements.define('dnk-sticky-atc', DnkStickyAtc);
}
