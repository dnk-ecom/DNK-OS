/**
 * --- DNK OS Zerno Flagship: Cart Drawer Custom Element ---
 * W3C Custom Element integrating with Event Bus and CartMutationQueue.
 */

if (!customElements.get('dnk-cart-drawer')) {
  class DnkCartDrawer extends HTMLElement {
    constructor() {
      super();
      this.isOpen = false;
      this._boundOpen = this._onOpen.bind(this);
      this._boundClose = this._onClose.bind(this);
      this._boundKeyDown = this._onKeyDown.bind(this);
      this._boundCartUpdated = this._onCartUpdated.bind(this);
      this._boundCartLoading = this._onCartLoading.bind(this);
      this._boundClick = this._handleClick.bind(this);
    }

    connectedCallback() {
      this.addEventListener('click', this._boundClick);
      window.addEventListener('keydown', this._boundKeyDown);

      if (window.DNK && window.DNK.events) {
        window.DNK.events.on('dnk:drawer:open', this._boundOpen);
        window.DNK.events.on('dnk:drawer:close', this._boundClose);
        window.DNK.events.on('dnk:cart:updated', this._boundCartUpdated);
        window.DNK.events.on('dnk:cart:loading', this._boundCartLoading);
      }
    }

    disconnectedCallback() {
      this.removeEventListener('click', this._boundClick);
      window.removeEventListener('keydown', this._boundKeyDown);

      if (window.DNK && window.DNK.events) {
        window.DNK.events.off('dnk:drawer:open', this._boundOpen);
        window.DNK.events.off('dnk:drawer:close', this._boundClose);
        window.DNK.events.off('dnk:cart:updated', this._boundCartUpdated);
        window.DNK.events.off('dnk:cart:loading', this._boundCartLoading);
      }
    }

    _onOpen(payload) {
      if (payload && payload.target && payload.target !== 'cart') return;
      this.open();
    }

    _onClose(payload) {
      if (payload && payload.target && payload.target !== 'cart') return;
      this.close();
    }

    open() {
      this.setAttribute('aria-hidden', 'false');
      this.isOpen = true;
      document.body.style.overflow = 'hidden';

      const closeBtn = this.querySelector('.dnk-cart-drawer__close');
      if (closeBtn) closeBtn.focus();
    }

    close() {
      this.setAttribute('aria-hidden', 'true');
      this.isOpen = false;
      document.body.style.overflow = '';
    }

    _onKeyDown(e) {
      if (e.key === 'Escape' && this.isOpen) {
        this.close();
      }
    }

    _onCartLoading(payload) {
      this.setAttribute('data-loading', 'true');
    }

    _onCartUpdated(cart) {
      this.removeAttribute('data-loading');
      // If sections payload was returned, render the updated drawer body
      if (cart && cart.sections && cart.sections['cart-drawer']) {
        this.renderContents(cart.sections['cart-drawer']);
      }
    }

    renderContents(htmlString) {
      const parser = new DOMParser();
      const doc = parser.parseFromString(htmlString, 'text/html');
      const newDrawer = doc.querySelector('dnk-cart-drawer');
      if (newDrawer) {
        this.innerHTML = newDrawer.innerHTML;
      }
    }

    _handleClick(e) {
      const target = e.target.closest('[data-action], [data-drawer-close]');
      if (!target) return;

      if (target.dataset.drawerClose === 'cart') {
        this.close();
        return;
      }

      const action = target.dataset.action;
      const key = target.dataset.itemKey;

      if (action === 'increase' && key) {
        const input = this.querySelector(`input[data-item-key="${key}"]`);
        const currentQty = parseInt(input ? input.value : '1', 10);
        if (window.DNK && window.DNK.cartQueue) {
          window.DNK.cartQueue.changeItem(key, currentQty + 1);
        }
      } else if (action === 'decrease' && key) {
        const input = this.querySelector(`input[data-item-key="${key}"]`);
        const currentQty = parseInt(input ? input.value : '1', 10);
        if (window.DNK && window.DNK.cartQueue) {
          window.DNK.cartQueue.changeItem(key, Math.max(0, currentQty - 1));
        }
      } else if (action === 'remove' && key) {
        if (window.DNK && window.DNK.cartQueue) {
          window.DNK.cartQueue.changeItem(key, 0);
        }
      } else if (action === 'add-upsell') {
        const variantId = target.dataset.variantId;
        if (variantId && window.DNK && window.DNK.cartQueue) {
          window.DNK.cartQueue.addItem(variantId, 1);
        }
      }
    }
  }

  customElements.define('dnk-cart-drawer', DnkCartDrawer);
}
